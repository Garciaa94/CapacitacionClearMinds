/**
 * 
 */
package com.cmc.exepciones;

/**
 * @author Adrian Garcia
 * @mail peter.garcia@pucese.edu.ec
 * @date 17 jul. 2021
 */
public class EvaluacionException extends Exception {
	public EvaluacionException(String msg) {
		super(msg);

	}
}
