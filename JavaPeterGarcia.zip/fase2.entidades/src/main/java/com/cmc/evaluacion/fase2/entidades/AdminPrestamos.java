/**
 * 
 */
package com.cmc.evaluacion.fase2.entidades;

/**
 * @author Adrian Garcia
 * @mail peter.garcia@pucese.edu.ec
 * @date  17 jul. 2021
 */
public class AdminPrestamos
{

	/**
	 * @param archivoPrestamos
	 * @param cartera
	 */
	public void colocarPrestamos(String archivoPrestamos, Cartera cartera) {
		// TODO Auto-generated method stub
		
	}
	

}
