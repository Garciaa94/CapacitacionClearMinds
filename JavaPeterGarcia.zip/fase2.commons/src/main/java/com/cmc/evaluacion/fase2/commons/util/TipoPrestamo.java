/**
 * 
 */
package com.cmc.evaluacion.fase2.commons.util;

/**
 * @author Adrian Garcia
 * @mail peter.garcia@pucese.edu.ec
 * @date  17 jul. 2021
 */
public class TipoPrestamo {
	public  static final String HIPOTECARIO ="H";
	public static final String QUIROGRAFARIO ="Q";
	public static final String OTRO ="O";
	

}
